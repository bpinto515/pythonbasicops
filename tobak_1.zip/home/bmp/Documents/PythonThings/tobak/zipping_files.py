#!/usr/bin/env python3
#
## BASIC SCRIPT TO BACKUP FILES TO ZIP